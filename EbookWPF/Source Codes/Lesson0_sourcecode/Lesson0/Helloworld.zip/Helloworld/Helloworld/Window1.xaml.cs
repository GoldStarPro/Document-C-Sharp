﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Helloworld
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        // khai báo 1 button
        Button button;
        public Window1()
        {
            InitializeComponent();
            //tạo mới button
            button = new Button();
            //xác định thuộc tính cho button
            button.Content = "Hello World";
            button.LayoutTransform = new ScaleTransform(3, 3);
            button.Margin = new System.Windows.Thickness(10);
            //thêm phương thức xử lý sự kiện Click cho button
            button.Click += new RoutedEventHandler(button_Click);
            //đưa button vao Window 
            this.Content = button; 
        }
        
        void button_Click(object sender, RoutedEventArgs e)
        {
            //xử lý button khi người dùng click
            button.Content = "From Hanoi, Vietnam";//đổi nội dung (caption) của button
        }

    }
}
